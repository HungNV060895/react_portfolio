import TodoList from "./components/todo.list"

function Layout() {
	
	return (
		<>
			<h1>Hello Vite + React!</h1>
			<TodoList />
		</>
	)
}

export default Layout
