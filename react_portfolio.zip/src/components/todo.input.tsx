import { useState } from "react";

interface ITodo {
    id: number;
	title: string;
	isComplete: boolean;
}

interface ITodoInput {
    name?: string,
    addNewTodo: (value: ITodo) => void;
}

const TodoInput = (props: ITodoInput) => {
    const [todo, setTodo] = useState<string>('');

    const {addNewTodo} = props;

    const handleTextchange = (event: React.ChangeEvent<HTMLInputElement>) =>  {
        setTodo(event.target.value);
    }

    const handleAddTodo = (data: ITodo) => {
        if(todo.trim() === '') {
            alert('Please enter your task!');
            return;
        }
        addNewTodo(data);
        setTodo('');
    }

    return (
        <>
            <dl style={{display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '10px'}}>
                <dt>Todo Input</dt>
                <dd>
                    <input type="text" placeholder="Enter your task...." value={todo} onChange={(event) => handleTextchange(event)}/>
                </dd>
            </dl>
            <button onClick={() => handleAddTodo({id: Date.now(), title: todo, isComplete: false})}>Add Todo</button>
        </>
    )
}

export default TodoInput;