
interface IProps {
    todos: {
        id: number;
        title: string;
        isComplete: boolean;
    }[],
    deleteTodo: (id: number) => void;
    owner?: string;
    age?: number;
    isDeveloper?: boolean;
}


const TodoData = (props: IProps) => {
    const {todos, deleteTodo} = props;

    // const handleDeleteTodo =  (id: number) => {
    //     console.log(todos);
    //     todos.filter((item) => item.id !== id);
    // }
    return (
        <>
            <h1>Todo Data</h1>
            <p>{todos.map((todo) => {
                return <li key={todo.id}>{todo.id} - {todo.title} <button onClick={() => deleteTodo(todo.id)}>Delete</button></li>;
            })}</p>
        </>
    )
}

export default TodoData;