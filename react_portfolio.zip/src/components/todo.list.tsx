import { useState } from "react";
import TodoData from "./todo.data";
import TodoInput from "./todo.input";

interface ITodo {
    id: number;
	title: string;
	isComplete: boolean;
}

const TodoList = () => {

	// const todos = [
	// 	{
	// 		id: 1,
	// 		title: "Learn React TypeScript",
	// 		isComplete: false
	// 	},
	// 	{
	// 		id: 2,
	// 		title: "Subscribe Youtube HoiDanIT",
	// 		isComplete: true
	// 	},
	// 	{
	// 		id: 3,
	// 		title: "Learn English",
	// 		isComplete: true
	// 	},
	// ]


	const addNewTodo = (todo: ITodo) => {
		setListTodo([...listTodo, todo]);
	}

	const deleteTodo = (id: number) => {
		const newListTodo = listTodo.filter((item) => item.id !== id);
		setListTodo(newListTodo);
	}

	const [listTodo, setListTodo] = useState<ITodo[]>([]);

	return (
		<>
			<h1>Todo List</h1>
			<h2>My todo list</h2>
			<TodoInput addNewTodo={addNewTodo} />
			<TodoData 
				todos={listTodo}
				deleteTodo={deleteTodo}
			/>
		</>
	)
}

export default TodoList;